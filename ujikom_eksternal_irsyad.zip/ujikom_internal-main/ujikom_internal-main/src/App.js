import "./App.css";
import ProjectsPage from "./components/ProjectsPage";
import Admin from "./components/admin/ProjectsPage";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./home/HomePage";
import AboutMePage from "./components/AboutMe";
import RencanakanPerjalanan from "./components/RencanakanPerjalanan"
import CulturalHistoryPortal from "./components/CulturalHistoryPortal";
import Login from "./components/Login";
import Navbar from "./components/Navbar";

function App() {
  return (
    <Router>
      <Navbar/>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/pariwisata" element={<ProjectsPage />} />
          <Route path="/pariwisata/admin" element={<Admin />} />
          <Route path="/about" element={<AboutMePage />} />
          <Route path="/rencanakanperjalanan" element={<RencanakanPerjalanan />} />
          <Route path="/budayadansejarah" element={<CulturalHistoryPortal />} />
          <Route path="/home" element={<HomePage />} />



        </Routes>
</Router>
  );
}

export default App;
