import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css';
import Footer from '../components/Footer/Footer';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const HomePage = () => {
  // Data destinasi wisata
  const destinations = [
    {
      id: 1,
      name: 'Pantai Kenjeran',
      description: 'Nikmati pesona pantai dengan pemandangan yang indah dan berbagai fasilitas rekreasi.',
      imageUrl: 'pantai surabaya.webp'
    },
    {
      id: 2,
      name: 'Museum Surabaya',
      description: 'Jelajahi sejarah dan budaya kota Surabaya melalui koleksi yang beragam di museum kami.',
      imageUrl: 'museum surabaya asoy.jpg'
    },
    {
      id: 3,
      name: 'Monumen Tugu Pahlawan',
      description: 'Monumen bersejarah dan saksi hidup kemerdekaan dalam mempertahankan NKRI',
      imageUrl: "tugu.jpg"
    }
    
  ];
  

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 3500,
    slidesToShow: 1,
    autoplay: true,
    autoplaySpeed: 100 ,
    slidesToScroll: 1,
    
    
  };
  return (
    <div className="container">
      <h2>Selamat Datang Di Soerabaya</h2>
    <Slider {...sliderSettings}>
        <div>
          <img src='museum surabaya asoy.jpg' alt="Slider Image 1" style={{width: "470%"}} />
        </div>
        <div>
          <img src='tentangsurabaya.jpg' alt="Slider Image 1" style={{width: "500%"}}  />
        </div>
        <div>
          <img src='pantai surabaya.webp' alt="Slider Image 1" style={{width: "100%"}} />
        </div>
      </Slider>
      <div style={{ marginTop: "50px", color: "black" }}></div>
      <p style={{justifyContent: "center"}}></p>

      
      
      
      <h1>Surabaya Tour Holiday  Siap Melayani Anda Selama Liburan di Soerabaya</h1>
      <p>Surabaya TOP HOLIDAY TOUR & TRAVEL menyediakan layanan Paket wisata  1 hari , 2 hari , 3 hari, Tour Group/Rombongan, Outing/Team Building dan berbagai wisata petualangan (adventure) di Surabaya. Pastikan liburan anda bersama guide dan driver yang ramah dan berkualitas!

Layanan kami yang profesional dan ramah akan memastikan anda memiliki liburan yang indah dan pengalaman yang tidak terlupakan...</p>

      
      
      <div className="destinations">
        {destinations.map(destination => (
          <div key={destination.id} className="destination">
            <img className='image' src={destination.imageUrl} alt={destination.name} />
            <h2>{destination.name}</h2>
            <p>{destination.description}</p>
            
            
            {/* <Link to={`/pariwisata/${destination.id}`} className="button">Lihat Detail</Link> */}
          </div>
        ))}
      </div>
  
      <Footer/>
    </div>
  );
};

export default HomePage;

