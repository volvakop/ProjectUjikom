import React from "react";
// import "./AboutMePage.css";

const AboutMePage = () => {
  return (
    <div className="container">
      <h2 className="heading">Kota Soerabaya</h2>
      <img src="tentangsurabaya.jpg"
      />
      <div className="paragraph">
        <p>
        (Jawa: Hanacaraka: ꦏꦹꦛꦯꦹꦫꦨꦪ; Pegon: كوڟا سورابايا), pengucapan bahasa Jawa: [kuʈɔ surɔˈbɔjɔ], Hanzi: 泗水, pelafalan dalam bahasa Indonesia:  adalah ibu kota Provinsi Jawa Timur yang menjadi pusat pemerintahan dan perekonomian dari Provinsi Jawa Timur sekaligus kota terbesar di provinsi tersebut. Surabaya juga merupakan sebuah kota yang terletak di Provinsi Jawa Timur, Indonesia. Surabaya merupakan kota terbesar kedua di Indonesia setelah Kota Jakarta. Kota ini terletak 800 km sebelah timur Jakarta, atau 435 km sebelah barat laut Denpasar, Bali. Letak kota ini berada di pantai utara Pulau Jawa bagian timur yang berhadapan dengan Selat Madura serta Laut Jawa.

Surabaya memiliki luas sekitar ±335,28 km², dan 3.000.076 jiwa penduduk pada pertengahan tahun 2023.[7] Daerah megalopolitan Surabaya yang berpenduduk sekitar 10 juta jiwa, adalah kawasan metropolitan terbesar kedua di Indonesia setelah Jabodetabek. Surabaya dan wilayah Gerbangkertosusila dilayani oleh sebuah bandar udara, yakni Bandar Udara Internasional Juanda yang berada 20 km di sebelah selatan kota, serta dua pelabuhan, yakni Pelabuhan Tanjung Perak dan Pelabuhan Ujung.

Surabaya dikenal dengan sebutan Kota Pahlawan karena Pertempuran 10 November 1945, yaitu sejarah perjuangan Arek-Arek Suroboyo (Pemuda-pemuda Surabaya) dalam mempertahankan kemerdekaan bangsa Indonesia dari serangan penjajah
        </p>
      </div>
    </div>
  );
};

export default AboutMePage;