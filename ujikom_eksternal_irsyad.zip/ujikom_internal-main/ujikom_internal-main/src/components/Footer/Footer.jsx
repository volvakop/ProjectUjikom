import React from "react";
import "./Footer.css"


function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="row">
          <div className="col-lg-4 col-md-6">
            <h3>Tentang Kami</h3>
            <p>Selamat datang di pariwasata Kota surabaya,temukan Destinasi terbaik Surabaya dengan menyewa jasa Travel Kami.</p>
          </div>
          <div className="col-lg-4 col-md-6">
            <h3>Destinasi Populer</h3>
            <ul>
              <li><a href="#">Pantai Ria Kanjeran</a></li>
              <li><a href="#">Tugu Pahlawan Soerabaya</a></li>
              <li><a href="#">Museum Kapal Selam</a></li>
            </ul>
          </div>
          <div className="col-lg-4 col-md-6">
            <h3>Hubungi Kami</h3>
            <p> Jalan ambarawa No. 123, Kota Surabaya</p>
            <p> pariwisatasurabaya@gmail.com</p>
            <p>Telp 08123456789</p>
            <p>@wisata_surabaya</p>
          </div>
        </div>
      </div>
      <div>
      </div>
      <div>
      <h4>copyright@2024</h4>
      </div>
    </footer>
  );
}

export default Footer;