import React, { useState } from "react";
import ProjectCard from "./ProjectCard";

const ProjectList = ({ projects }) => {
  const [projectBeingEdited] = useState(null);


  return (
    <div className="baris">
      {projects.map((project) => (
        <div key={project.id} className="cols-row">
          <ProjectCard
            project={project}

            isEditing={project === projectBeingEdited}
          />
        </div>
      ))}
    </div>
  );
};

export default ProjectList;
