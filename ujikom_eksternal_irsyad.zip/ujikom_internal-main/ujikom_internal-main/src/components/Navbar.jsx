import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import "../App.css";

const Navbar = () => {
  const location = useLocation();

  // Define paths where you want to hide the navbar
  const pathsToHideNavbar = ["/", "/pariwisata/admin"];

  // Check if the current location matches any path in pathsToHideNavbar
  const isHidden = pathsToHideNavbar.includes(location.pathname);

  // If the navbar should be hidden, return null
  if (isHidden) {
    return null;
  }

  // If the navbar should be visible, render it
  return (
    <header className="sticky">
      <span className="logo">
        <img src="wonderfull.jpg" alt="logo" width="120px" height="20px" />
      </span>

      <NavLink to="/home" className="button rounded">
        <span className="icon-home"></span>
        Home
      </NavLink>
      <NavLink to="/pariwisata" className="button rounded">
        Destinasi
      </NavLink>
      <NavLink to="/about" className="button rounded">
        Tentang Surabaya
      </NavLink>
      <NavLink to="/rencanakanperjalanan" className="button rounded">
        Rencanakan Perjalanan
      </NavLink>
      <NavLink to="/budayadansejarah" className="button rounded">
        Budaya Dan Sejarah
      </NavLink>
    </header>
  );
};

export default Navbar;
